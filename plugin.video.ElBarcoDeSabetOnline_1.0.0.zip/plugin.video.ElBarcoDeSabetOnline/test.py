from core import CoreAddon

addon_dir = "/fake/addon/path"
cache_file = "/fake/addon/path/cache.json"
core = CoreAddon(addon_dir, cache_file)

core.get_tv_programs()
